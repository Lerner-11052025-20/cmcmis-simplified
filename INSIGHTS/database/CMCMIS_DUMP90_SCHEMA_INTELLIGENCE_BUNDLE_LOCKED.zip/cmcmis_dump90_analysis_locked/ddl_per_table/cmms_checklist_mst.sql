-- CMCMIS dump90tables schema-only extraction
-- Source: dump90tables.sql inside dump90tables.zip
-- Extracted: 2026-05-18 15:10:22
-- Source SHA256: dd57e353524636a960f04c0fcd658fb8428ecd6e88e653e52a399b81381ffc6a
-- Note: data INSERT statements intentionally removed. Review before running in production.

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

CREATE TABLE `cmms_checklist_mst` (
  `CHKL_ID` int(11) NOT NULL,
  `CHKL_TYPE` varchar(50) NOT NULL,
  `CHKL_MAKE` int(11) NOT NULL,
  `CHKL_MODEL` varchar(50) NOT NULL,
  `CHKL_STATE` tinyint(1) NOT NULL,
  `CHKL_CREATED_BY` varchar(7) NOT NULL,
  `CHKL_CREATED_ON` datetime(6) NOT NULL,
  `CHKL_UPDATED_BY` varchar(7) NOT NULL,
  `CHKL_UPDATED_ON` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE `cmms_checklist_mst`
  ADD PRIMARY KEY (`CHKL_ID`),
  ADD KEY `FK_CMMS_CHECKLIST_MST_CMMS_CONT_MST` (`CHKL_MAKE`);
ALTER TABLE `cmms_checklist_mst`
  ADD CONSTRAINT `FK_CMMS_CHECKLIST_MST_CMMS_CONT_MST` FOREIGN KEY (`CHKL_MAKE`) REFERENCES `cmms_cont_mst` (`CMM_CONT_ID`);
